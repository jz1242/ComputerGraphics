#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "rayTriangle.h"

////////////////////////
//  Ray-tracing stuff //
////////////////////////
void RayTriangle::initialize( void )
{
	static bool firstTime = true;
	if( firstTime ) fprintf( stderr , "[WARNING] RayTriangle::intialize undefined" );
	firstTime = false;
}
double RayTriangle::intersect( Ray3D ray , RayIntersectionInfo& iInfo , double mx )
{
	throw RayException( "RayTriangle::intersect undefined" );
	return -1;
}
BoundingBox3D RayTriangle::setBoundingBox( void )
{
	throw RayException( "RayTriangle::setBoundingBox undefined" );
	return bBox;
}

//////////////////
// OpenGL stuff //
//////////////////
int RayTriangle::drawOpenGL( int materialIndex , GLSLProgram * glslProgram )
{
	throw RayException( "RayTriangle::drawOpenGL undefined" );
	return -1;
}
